package com.techprimers.kafka.springbootkafkaconsumerexample.timepckg;

import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;

@Component
public class TimeClass {
    private String pattern = "HH:mm:ss:SSSS";
    String date;
    SimpleDateFormat simpleDateFormat;
    public TimeClass(){
        simpleDateFormat = new SimpleDateFormat(pattern);
    }
    public String printTime(){
        date = simpleDateFormat.format(new Date());
        return date;
    }
}
