package com.techprimers.kafka.springbootkafkaconsumerexample.producer;

import com.techprimers.kafka.springbootkafkaconsumerexample.timepckg.TimeClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class MessageProducerImpl {

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;
    @Autowired
    TimeClass timeClass;
    private static final String TOPIC = "hassanTwo";


    public void publishToQueue(String value) {
        //sending back ack
        System.out.println("Sending back msg for ack "+timeClass.printTime());
        kafkaTemplate.send(TOPIC, value);
    }
}