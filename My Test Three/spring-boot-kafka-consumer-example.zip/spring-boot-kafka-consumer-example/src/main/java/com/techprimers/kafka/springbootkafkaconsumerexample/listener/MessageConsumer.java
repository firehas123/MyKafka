package com.techprimers.kafka.springbootkafkaconsumerexample.listener;

import com.techprimers.kafka.springbootkafkaconsumerexample.producer.MessageProducerImpl;
import com.techprimers.kafka.springbootkafkaconsumerexample.timepckg.TimeClass;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;

@Component
public class MessageConsumer {

    //private static final String TOPIC = "message.topic";

    private static final String TOPIC = "hassan";

    @Autowired
    TimeClass timeClass;
    @Autowired
    private MessageProducerImpl messageProducer;

    @KafkaListener(topics = TOPIC)
    public void messageListener(ConsumerRecord<String, String> consumerRecord, Acknowledgment ack, @Header("kafka_offset") int offSet) {
        System.out.println("Consumed message : " + consumerRecord.value()  +" at time " + timeClass.printTime() );
        messageProducer.publishToQueue(consumerRecord.value());


    }
}